from sympy.liealgebras.cartan_type import CartanType
