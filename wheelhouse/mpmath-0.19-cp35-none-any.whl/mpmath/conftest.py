import os

# This makes py.test put mpath directory into the sys.path, so that we can
# import mpmath" from tests nicely
rootdir = os.path.abspath(os.getcwd())
